<?php
define('URL', 'http://shenkar.html5-book.co.il/2017-2018/html5/dev_247/');
?>